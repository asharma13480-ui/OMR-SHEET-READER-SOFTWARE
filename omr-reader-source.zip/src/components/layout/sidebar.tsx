'use client';

import { useAppStore, PageType } from '@/lib/store';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  FilePlus2,
  KeyRound,
  Upload,
  ScanLine,
  BarChart3,
  Trophy,
  FileText,
  FileDown,
  TableProperties,
  DatabaseBackup,
  FilePlus2 as ClipboardPlus,
  Settings,
  ShieldCheck,
  HelpCircle,
  X,
} from 'lucide-react';

interface NavItem {
  id: PageType;
  label: string;
  icon: React.ElementType;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'create-exam', label: 'Create Exam', icon: FilePlus2 },
  { id: 'upload-answer-key', label: 'Answer Key', icon: KeyRound },
  { id: 'upload-omr', label: 'Upload OMR', icon: Upload },
  { id: 'check-omr', label: 'Check OMR', icon: ScanLine },
  { id: 'results', label: 'Results', icon: BarChart3 },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'merit-list', label: 'Merit List', icon: Trophy },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'export-pdf', label: 'Export PDF', icon: FileDown },
  { id: 'export-excel', label: 'Export Excel', icon: TableProperties },
  { id: 'backup', label: 'Backup', icon: DatabaseBackup },
  { id: 'omr-template', label: 'OMR Template', icon: ClipboardPlus },
  { id: 'license-management', label: 'License Keys', icon: ShieldCheck },
  { id: 'settings', label: 'Settings', icon: Settings },
  { id: 'help', label: 'Help & Deploy', icon: HelpCircle },
];

export function Sidebar() {
  const currentPage = useAppStore((s) => s.currentPage);
  const setCurrentPage = useAppStore((s) => s.setCurrentPage);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const appSettings = useAppStore((s) => s.appSettings);

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-sidebar-border shrink-0">
        <div className="w-14 h-14 rounded-2xl overflow-hidden bg-white flex-shrink-0 ring-2 ring-primary/40 shadow-lg shadow-primary/20 flex items-center justify-center">
          <img src={appSettings.logoUrl} alt={appSettings.appName} className="w-10 h-10 object-contain" />
        </div>
        <div className="min-w-0">
          <h1 className="text-lg font-extrabold text-sidebar-foreground truncate tracking-tight">{appSettings.appName}</h1>
          <p className="text-xs text-defence-accent font-bold tracking-widest uppercase">{appSettings.appSubtitle}</p>
        </div>
        <button
          onClick={() => setSidebarOpen(false)}
          className="lg:hidden ml-auto text-sidebar-foreground/60 hover:text-sidebar-foreground"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden py-2 px-2 space-y-0.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setCurrentPage(item.id);
                setSidebarOpen(false);
              }}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200',
                isActive
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-sidebar-border shrink-0">
        <p className="text-[10px] text-sidebar-foreground/40 text-center leading-relaxed">
          v1.0.0 • {appSettings.appName}
        </p>
      </div>
    </div>
  );
}

export function MobileSidebar() {
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);

  return (
    <>
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <div
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-72 bg-sidebar text-sidebar-foreground transform transition-transform duration-300 lg:hidden',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <Sidebar />
      </div>
    </>
  );
}

export function MobileHeader() {
  const currentPage = useAppStore((s) => s.currentPage);
  const setSidebarOpen = useAppStore((s) => s.setSidebarOpen);
  const appSettings = useAppStore((s) => s.appSettings);
  const pageLabels: Record<PageType, string> = {
    'dashboard': 'Dashboard',
    'create-exam': 'Create Exam',
    'upload-answer-key': 'Upload Answer Key',
    'upload-omr': 'Upload OMR Sheets',
    'check-omr': 'Check OMR',
    'results': 'Results',
    'analytics': 'Analytics',
    'merit-list': 'Merit List',
    'reports': 'Reports',
    'export-pdf': 'Export PDF',
    'export-excel': 'Export Excel',
    'backup': 'Backup',
    'license-management': 'License Keys',
    'settings': 'Settings',
    'omr-template': 'OMR Template',
    'help': 'Help & Deploy',
  };

  return (
    <header className="lg:hidden sticky top-0 z-30 bg-sidebar text-sidebar-foreground flex items-center gap-3 px-4 py-3 shadow-lg shadow-black/10">
      <button
        onClick={() => setSidebarOpen(true)}
        className="p-2 rounded-lg hover:bg-sidebar-accent"
      >
        <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <div className="flex items-center gap-2.5">
        <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center ring-2 ring-primary/40 shadow-md">
          <img src={appSettings.logoUrl} alt="" className="w-8 h-8 object-contain" />
        </div>
        <div className="min-w-0">
          <h1 className="text-sm font-bold truncate">{pageLabels[currentPage]}</h1>
          <p className="text-[10px] text-defence-accent font-semibold tracking-wider">{appSettings.appSubtitle}</p>
        </div>
      </div>
    </header>
  );
}