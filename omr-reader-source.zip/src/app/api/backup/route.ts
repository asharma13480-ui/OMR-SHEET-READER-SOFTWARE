import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const [exams, answerKeys, omrSheets, results, settings] = await Promise.all([
      db.exam.count(),
      db.answerKey.count(),
      db.oMRSheet.count(),
      db.result.count(),
      db.appSettings.count(),
    ]);

    const backupData = {
      exportDate: new Date().toISOString(),
      version: '1.0.0',
      application: 'OMR Sheet Reader',
      info: {
        exams,
        answerKeys,
        omrSheets,
        results,
        settings,
        totalRecords: exams + answerKeys + omrSheets + results + settings,
      },
      data: {
        exams: await db.exam.findMany(),
        answerKeys: await db.answerKey.findMany(),
        omrSheets: await db.oMRSheet.findMany(),
        results: await db.result.findMany(),
        settings: await db.appSettings.findMany(),
      },
    };

    return NextResponse.json(backupData);
  } catch (error) {
    console.error('Error creating backup:', error);
    return NextResponse.json({ error: 'Failed to create backup' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    const fileContent = await file.text();
    const backupData = JSON.parse(fileContent);

    if (!backupData.data) {
      return NextResponse.json({ error: 'Invalid backup file format' }, { status: 400 });
    }

    // Restore data - delete existing and recreate
    // Note: SQLite cascade deletes will handle related records
    if (backupData.data.exams && Array.isArray(backupData.data.exams)) {
      await db.result.deleteMany();
      await db.answerKey.deleteMany();
      await db.oMRSheet.deleteMany();
      await db.exam.deleteMany();

      for (const exam of backupData.data.exams) {
        const { id, createdAt, updatedAt, ...data } = exam;
        await db.exam.create({ data });
      }
    }

    if (backupData.data.answerKeys && Array.isArray(backupData.data.answerKeys)) {
      await db.answerKey.deleteMany();
      for (const ak of backupData.data.answerKeys) {
        const { id, ...data } = ak;
        await db.answerKey.create({ data });
      }
    }

    if (backupData.data.omrSheets && Array.isArray(backupData.data.omrSheets)) {
      await db.oMRSheet.deleteMany();
      for (const sheet of backupData.data.omrSheets) {
        const { id, createdAt, updatedAt, ...data } = sheet;
        await db.oMRSheet.create({ data });
      }
    }

    if (backupData.data.results && Array.isArray(backupData.data.results)) {
      await db.result.deleteMany();
      for (const result of backupData.data.results) {
        const { id, createdAt, updatedAt, ...data } = result;
        await db.result.create({ data });
      }
    }

    if (backupData.data.settings && Array.isArray(backupData.data.settings)) {
      await db.appSettings.deleteMany();
      for (const setting of backupData.data.settings) {
        const { id, ...data } = setting;
        await db.appSettings.create({ data });
      }
    }

    const [exams, answerKeys, omrSheets, results, settings] = await Promise.all([
      db.exam.count(),
      db.answerKey.count(),
      db.oMRSheet.count(),
      db.result.count(),
      db.appSettings.count(),
    ]);

    return NextResponse.json({
      success: true,
      message: 'Backup restored successfully',
      info: {
        exams,
        answerKeys,
        omrSheets,
        results,
        settings,
        totalRecords: exams + answerKeys + omrSheets + results + settings,
      },
    });
  } catch (error) {
    console.error('Error restoring backup:', error);
    return NextResponse.json({ error: 'Failed to restore backup' }, { status: 500 });
  }
}
