import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/answer-key?examId=xxx — get answer key for an exam
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    const answerKey = await db.answerKey.findMany({
      where: { examId },
      orderBy: { questionNo: 'asc' },
    });

    return NextResponse.json({ answerKey });
  } catch (error) {
    console.error('GET /api/answer-key error:', error);
    return NextResponse.json({ error: 'Failed to fetch answer key' }, { status: 500 });
  }
}

// POST /api/answer-key — save answer key entries (upsert)
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { examId, answers } = body;

    if (!examId || !answers || !Array.isArray(answers)) {
      return NextResponse.json({ error: 'examId and answers array are required' }, { status: 400 });
    }

    // Upsert each answer key entry
    for (const entry of answers) {
      const { questionNo, correctAnswer, marks } = entry;
      if (!correctAnswer) continue;

      await db.answerKey.upsert({
        where: {
          examId_questionNo: {
            examId,
            questionNo: parseInt(questionNo),
          },
        },
        update: {
          correctAnswer: correctAnswer.toUpperCase(),
          marks: parseFloat(marks) || 1,
        },
        create: {
          examId,
          questionNo: parseInt(questionNo),
          correctAnswer: correctAnswer.toUpperCase(),
          marks: parseFloat(marks) || 1,
        },
      });
    }

    return NextResponse.json({ success: true, count: answers.length });
  } catch (error) {
    console.error('POST /api/answer-key error:', error);
    return NextResponse.json({ error: 'Failed to save answer key' }, { status: 500 });
  }
}
