import { NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

// ─── Types ───────────────────────────────────────────────────────

interface ScanSheetResult {
  fileName: string;
  fileSize: number;
  success: boolean;
  rollNumber: string;
  studentName: string;
  mobileNumber: string;
  className: string;
  section: string;
  batch: string;
  answers: string[];
  answeredCount: number;
  totalQuestions: number;
  confidence: number;
  error?: string;
}

interface VLMResponse {
  rollNumber: string;
  studentName: string;
  mobileNumber: string;
  className: string;
  section: string;
  batch: string;
  answers: string[];
}

// ─── Helpers ─────────────────────────────────────────────────────

function buildOMRPrompt(totalQuestions: number, optionsPerQ: number): string {
  const extraOptions: string[] = [];
  if (optionsPerQ > 4) extraOptions.push(', E');
  if (optionsPerQ > 5) extraOptions.push(', F');

  return `You are an OMR (Optical Mark Recognition) sheet scanner. Analyze this image of an OMR answer sheet carefully.

Extract ALL of the following information from the sheet:
1. Student Name: Look for handwritten or printed student name anywhere on the sheet
2. Roll Number: Find the roll number (usually at the top, bottom, or in a dedicated bubble region)
3. Mobile Number: Look for a mobile/phone number written on the sheet
4. Class: Find the class or course name/number
5. Section: Find the section (e.g., A, B, C)
6. Batch: Find the batch number or year
7. Answers: For each question (1 to ${totalQuestions}), identify which bubble is filled. Options are A, B, C, D${extraOptions.join('')}.

Return ONLY valid JSON in this exact format:
{
  "studentName": "Full Name",
  "rollNumber": "001",
  "mobileNumber": "9876543210",
  "className": "Class 10",
  "section": "A",
  "batch": "2025",
  "answers": ["A","B","C","D","A",...]
}

Important rules:
- If you CANNOT detect a field, use "" (empty string) for that field
- For each question, if no bubble is clearly filled, use "X" as the answer
- answers array MUST have exactly ${totalQuestions} entries
- Only return the JSON object, no explanation text`;
}

function parseVLMResponse(raw: string, totalQuestions: number): VLMResponse | null {
  let jsonStr = raw.trim();

  // Remove markdown code fences if present
  const codeBlockMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlockMatch) {
    jsonStr = codeBlockMatch[1].trim();
  }

  // Try to find JSON object in the response
  const jsonMatch = jsonStr.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    jsonStr = jsonMatch[0];
  }

  try {
    const parsed = JSON.parse(jsonStr);

    const studentName = String(parsed.studentName || '').trim();
    const rollNumber = String(parsed.rollNumber || '').trim();
    const mobileNumber = String(parsed.mobileNumber || '').trim();
    const className = String(parsed.className || '').trim();
    const section = String(parsed.section || '').trim();
    const batch = String(parsed.batch || '').trim();
    const rawAnswers = Array.isArray(parsed.answers) ? parsed.answers : [];

    // Normalize answers: ensure we have exactly totalQuestions entries
    const answers: string[] = [];
    for (let i = 0; i < totalQuestions; i++) {
      if (i < rawAnswers.length) {
        const a = String(rawAnswers[i]).toUpperCase().trim();
        if (/^[A-FX]$/.test(a)) {
          answers.push(a === 'X' ? '' : a);
        } else {
          answers.push('');
        }
      } else {
        answers.push('');
      }
    }

    return { rollNumber, studentName, mobileNumber, className, section, batch, answers };
  } catch {
    return null;
  }
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const chunks: string[] = [];
  const bytes = new Uint8Array(buffer);
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    chunks.push(String.fromCharCode(...chunk));
  }
  return btoa(chunks.join(''));
}

async function analyzeSheet(
  zai: Awaited<ReturnType<typeof ZAI.create>>,
  base64Image: string,
  totalQuestions: number,
  optionsPerQ: number
): Promise<VLMResponse> {
  const prompt = buildOMRPrompt(totalQuestions, optionsPerQ);

  const response = await zai.chat.completions.createVision({
    messages: [
      {
        role: 'user',
        content: [
          { type: 'text', text: prompt },
          {
            type: 'image_url',
            image_url: { url: `data:image/jpeg;base64,${base64Image}` },
          },
        ],
      },
    ],
    thinking: { type: 'disabled' },
  });

  const content = response.choices?.[0]?.message?.content;
  if (!content) {
    throw new Error('Empty response from VLM');
  }

  const parsed = parseVLMResponse(content, totalQuestions);
  if (!parsed) {
    throw new Error('Failed to parse VLM response as valid JSON');
  }

  return parsed;
}

// ─── POST Handler ────────────────────────────────────────────────
// This endpoint scans OMR images using VLM and returns detection results.
// It does NOT save sheets to the database — the frontend saves via /api/omr/bulk
// after the user reviews/edits the results.

export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const examId = formData.get('examId') as string | null;

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    // We don't need the exam from DB anymore since we don't save here,
    // but we still need totalQuestions and optionsPerQ from the request
    const totalQuestionsStr = formData.get('totalQuestions') as string | null;
    const optionsPerQStr = formData.get('optionsPerQ') as string | null;
    const totalQuestions = totalQuestionsStr ? parseInt(totalQuestionsStr) : 100;
    const optionsPerQ = optionsPerQStr ? parseInt(optionsPerQStr) : 4;

    if (totalQuestions < 1 || totalQuestions > 500) {
      return NextResponse.json({ error: 'totalQuestions must be between 1 and 500' }, { status: 400 });
    }

    // Collect image files from form data
    const files: File[] = [];
    const entries = formData.entries();
    for (const [key, value] of entries) {
      if (key === 'examId' || key === 'totalQuestions' || key === 'optionsPerQ') continue;
      if (value instanceof File) {
        // Check extension from both the filename and content type
        const ext = value.name.split('.').pop()?.toLowerCase() || '';
        const supportedExts = ['jpg', 'jpeg', 'png', 'webp'];
        if (!supportedExts.includes(ext)) {
          console.warn(`Skipping unsupported file: ${value.name} (extension: ${ext})`);
          // Continue processing other files instead of failing entirely
          continue;
        }
        if (value.size > 20 * 1024 * 1024) {
          console.warn(`Skipping too large file: ${value.name} (size: ${value.size})`);
          continue;
        }
        files.push(value);
      }
    }

    if (files.length === 0) {
      return NextResponse.json({ error: 'No image files provided' }, { status: 400 });
    }

    if (files.length > 500) {
      return NextResponse.json(
        { error: `Too many files: ${files.length}. Maximum 500 images per batch.` },
        { status: 400 }
      );
    }

    // Initialize VLM client
    const zai = await ZAI.create();

    const results: ScanSheetResult[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const arrayBuffer = await file.arrayBuffer();
        const base64Image = arrayBufferToBase64(arrayBuffer);

        const vlmResult = await analyzeSheet(
          zai,
          base64Image,
          totalQuestions,
          optionsPerQ
        );

        const answeredCount = vlmResult.answers.filter((a) => a !== '').length;
        const confidence = totalQuestions > 0 ? answeredCount / totalQuestions : 0;

        results.push({
          fileName: file.name,
          fileSize: file.size,
          success: true,
          rollNumber: vlmResult.rollNumber,
          studentName: vlmResult.studentName,
          mobileNumber: vlmResult.mobileNumber,
          className: vlmResult.className,
          section: vlmResult.section,
          batch: vlmResult.batch,
          answers: vlmResult.answers,
          answeredCount,
          totalQuestions,
          confidence,
        });
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Unknown error';
        console.error(`Failed to process sheet ${file.name}:`, errorMsg);

        results.push({
          fileName: file.name,
          fileSize: file.size,
          success: false,
          rollNumber: '',
          studentName: '',
          mobileNumber: '',
          className: '',
          section: '',
          batch: '',
          answers: Array(totalQuestions).fill(''),
          answeredCount: 0,
          totalQuestions,
          confidence: 0,
          error: errorMsg,
        });
      }
    }

    const successCount = results.filter((r) => r.success).length;
    const failCount = results.filter((r) => !r.success).length;

    return NextResponse.json({
      success: successCount,
      failed: failCount,
      total: results.length,
      results,
    });
  } catch (error) {
    console.error('POST /api/omr/scan error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to scan OMR sheets' },
      { status: 500 }
    );
  }
}
