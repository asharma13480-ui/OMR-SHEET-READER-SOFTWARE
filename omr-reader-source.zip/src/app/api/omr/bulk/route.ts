import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/omr/bulk — batch create OMR sheets
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { examId, sheets } = body;

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    if (!sheets || !Array.isArray(sheets) || sheets.length === 0) {
      return NextResponse.json({ error: 'sheets array is required and must not be empty' }, { status: 400 });
    }

    if (sheets.length > 1000) {
      return NextResponse.json({ error: 'Maximum 1000 sheets per batch' }, { status: 400 });
    }

    // Verify exam exists
    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json({ error: 'Exam not found. Please select a valid exam.' }, { status: 404 });
    }

    // Validate required fields for each sheet
    for (let i = 0; i < sheets.length; i++) {
      const s = sheets[i];
      if (!s.studentName?.trim()) {
        return NextResponse.json(
          { error: `Row ${i + 1}: studentName is required` },
          { status: 400 }
        );
      }
      if (!s.rollNumber?.trim()) {
        return NextResponse.json(
          { error: `Row ${i + 1}: rollNumber is required` },
          { status: 400 }
        );
      }
    }

    // Create all sheets in a transaction
    const result = await db.$transaction(
      sheets.map((s: { studentName: string; rollNumber: string; className?: string; section?: string; batch?: string; answers: string[] }) => {
        const parsedAnswers = Array.isArray(s.answers) ? s.answers : [];
        return db.oMRSheet.create({
          data: {
            examId,
            studentName: s.studentName.trim(),
            rollNumber: s.rollNumber.trim(),
            className: s.className?.trim() || null,
            section: s.section?.trim() || null,
            batch: s.batch?.trim() || null,
            answers: JSON.stringify(parsedAnswers),
            status: 'pending',
          },
        });
      })
    );

    return NextResponse.json({
      count: result.length,
      message: `Successfully created ${result.length} OMR sheets`,
    });
  } catch (error) {
    console.error('POST /api/omr/bulk error:', error);
    return NextResponse.json({ error: 'Failed to create OMR sheets' }, { status: 500 });
  }
}
