import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { unlink } from 'fs/promises';
import path from 'path';

// GET /api/omr/[id] - Get single OMR sheet
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const sheet = await db.oMRSheet.findUnique({
      where: { id },
      include: {
        exam: {
          select: {
            id: true,
            name: true,
            totalQuestions: true,
            totalMarks: true,
            negativeMarking: true,
          },
        },
        results: true,
      },
    });

    if (!sheet) {
      return NextResponse.json(
        { error: 'OMR sheet not found' },
        { status: 404 }
      );
    }

    // Parse answers from JSON string
    const parsedAnswers = JSON.parse(sheet.answers);

    return NextResponse.json({
      data: {
        ...sheet,
        parsedAnswers,
      },
    });
  } catch (error) {
    console.error('Error fetching OMR sheet:', error);
    return NextResponse.json(
      { error: 'Failed to fetch OMR sheet' },
      { status: 500 }
    );
  }
}

// DELETE /api/omr/[id] - Delete OMR sheet
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const sheet = await db.oMRSheet.findUnique({
      where: { id },
    });

    if (!sheet) {
      return NextResponse.json(
        { error: 'OMR sheet not found' },
        { status: 404 }
      );
    }

    // Delete associated results first
    await db.result.deleteMany({ where: { omrSheetId: id } });

    // Delete file if exists
    if (sheet.filePath) {
      try {
        const fullPath = path.join(process.cwd(), sheet.filePath);
        await unlink(fullPath);
      } catch {
        // File may not exist, ignore error
      }
    }

    // Delete the OMR sheet
    await db.oMRSheet.delete({ where: { id } });

    return NextResponse.json({ message: 'OMR sheet deleted successfully' });
  } catch (error) {
    console.error('Error deleting OMR sheet:', error);
    return NextResponse.json(
      { error: 'Failed to delete OMR sheet' },
      { status: 500 }
    );
  }
}
