import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/omr?examId=xxx — get OMR sheets for an exam
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');

    const sheets = await db.oMRSheet.findMany({
      where: examId ? { examId } : undefined,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ sheets });
  } catch (error) {
    console.error('GET /api/omr error:', error);
    return NextResponse.json({ error: 'Failed to fetch OMR sheets' }, { status: 500 });
  }
}

// POST /api/omr — create a new OMR sheet
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { examId, studentName, rollNumber, className, section, batch, answers } = body;

    if (!examId || !studentName?.trim() || !rollNumber?.trim()) {
      return NextResponse.json(
        { error: 'examId, studentName, and rollNumber are required' },
        { status: 400 }
      );
    }

    // Verify exam exists
    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json(
        { error: 'Exam not found. Please select a valid exam.' },
        { status: 404 }
      );
    }

    // Validate answers array
    const parsedAnswers = Array.isArray(answers) ? answers : [];
    if (parsedAnswers.length === 0) {
      console.warn(`OMR sheet for ${studentName} has no answers`);
    }

    const sheet = await db.oMRSheet.create({
      data: {
        examId,
        studentName: studentName.trim(),
        rollNumber: rollNumber.trim(),
        className: className?.trim() || null,
        section: section?.trim() || null,
        batch: batch?.trim() || null,
        answers: JSON.stringify(parsedAnswers),
        status: 'pending',
      },
    });

    return NextResponse.json({ sheet }, { status: 201 });
  } catch (error) {
    console.error('POST /api/omr error:', error);
    return NextResponse.json({ error: 'Failed to create OMR sheet' }, { status: 500 });
  }
}
