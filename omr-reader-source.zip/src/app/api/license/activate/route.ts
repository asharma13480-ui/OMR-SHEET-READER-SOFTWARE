import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

const TYPE_DURATIONS: Record<string, number | null> = {
  trial: 7,
  monthly: 30,
  yearly: 365,
  lifetime: null,
};

// POST /api/license/activate — activate a license key
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { key, deviceInfo } = body;

    if (!key) {
      return NextResponse.json({ error: 'License key is required' }, { status: 400 });
    }

    const license = await db.licenseKey.findUnique({ where: { key: key.trim().toUpperCase() } });

    if (!license) {
      return NextResponse.json({ error: 'Invalid license key' }, { status: 404 });
    }

    if (license.status === 'revoked') {
      return NextResponse.json({ error: 'This license key has been revoked' }, { status: 403 });
    }

    if (license.status === 'active') {
      // Already active - return current info
      const now = new Date();
      const expired = license.expiresAt && license.expiresAt < now;
      if (expired) {
        await db.licenseKey.update({
          where: { id: license.id },
          data: { status: 'expired' },
        });
        return NextResponse.json({ error: 'This license key has expired' }, { status: 403 });
      }

      const daysRemaining = license.expiresAt
        ? Math.max(0, Math.ceil((license.expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
        : Infinity;

      return NextResponse.json({
        success: true,
        license: {
          id: license.id,
          key: license.key,
          type: license.type,
          status: license.status,
          activatedAt: license.activatedAt,
          expiresAt: license.expiresAt,
          daysRemaining,
        },
      });
    }

    if (license.status === 'expired') {
      return NextResponse.json({ error: 'This license key has expired' }, { status: 403 });
    }

    // Activate the key
    const now = new Date();
    const duration = TYPE_DURATIONS[license.type];
    const expiresAt = duration ? new Date(now.getTime() + duration * 24 * 60 * 60 * 1000) : null;

    const updated = await db.licenseKey.update({
      where: { id: license.id },
      data: {
        status: 'active',
        activatedAt: now,
        expiresAt,
        deviceInfo: deviceInfo || null,
      },
    });

    const daysRemaining = expiresAt
      ? Math.max(0, Math.ceil((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
      : Infinity;

    return NextResponse.json({
      success: true,
      license: {
        id: updated.id,
        key: updated.key,
        type: updated.type,
        status: updated.status,
        activatedAt: updated.activatedAt,
        expiresAt: updated.expiresAt,
        daysRemaining,
      },
    });
  } catch (error) {
    console.error('POST /api/license/activate error:', error);
    return NextResponse.json({ error: 'Failed to activate license' }, { status: 500 });
  }
}