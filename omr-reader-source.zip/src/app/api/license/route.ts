import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

function generateKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const seg = () =>
    Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `DT-${seg()}-${seg()}-${seg()}`;
}

// GET /api/license — list all license keys with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const search = searchParams.get('search');
    const page = parseInt(searchParams.get('page') || '1', 10);
    const limit = parseInt(searchParams.get('limit') || '50', 10);

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (type) where.type = type;
    if (search) {
      where.key = { contains: search };
    }

    const [keys, total] = await Promise.all([
      db.licenseKey.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.licenseKey.count({ where }),
    ]);

    return NextResponse.json({ keys, total, page, limit });
  } catch (error) {
    console.error('GET /api/license error:', error);
    return NextResponse.json({ error: 'Failed to fetch license keys' }, { status: 500 });
  }
}

// POST /api/license — generate new license keys
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { count, type } = body;

    const licenseType = type || 'monthly';
    if (!['trial', 'monthly', 'yearly', 'lifetime'].includes(licenseType)) {
      return NextResponse.json({ error: 'Invalid license type' }, { status: 400 });
    }

    const numKeys = Math.min(Math.max(parseInt(count) || 1, 1), 500);
    const keys: string[] = [];

    for (let i = 0; i < numKeys; i++) {
      let key: string;
      let exists = true;
      let attempts = 0;
      do {
        key = generateKey();
        const found = await db.licenseKey.findUnique({ where: { key } });
        if (!found) exists = false;
        attempts++;
      } while (exists && attempts < 10);

      keys.push(key);
      await db.licenseKey.create({
        data: { key, type: licenseType },
      });
    }

    return NextResponse.json({ keys, count: keys.length, type: licenseType }, { status: 201 });
  } catch (error) {
    console.error('POST /api/license error:', error);
    return NextResponse.json({ error: 'Failed to generate license keys' }, { status: 500 });
  }
}

// PUT /api/license — revoke a license key
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, action } = body;

    if (!id || !action) {
      return NextResponse.json({ error: 'ID and action are required' }, { status: 400 });
    }

    if (action === 'revoke') {
      const updated = await db.licenseKey.update({
        where: { id },
        data: { status: 'revoked' },
      });
      return NextResponse.json({ key: updated });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('PUT /api/license error:', error);
    return NextResponse.json({ error: 'Failed to update license key' }, { status: 500 });
  }
}

// DELETE /api/license — delete a license key
export async function DELETE(request: Request) {
  try {
    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    await db.licenseKey.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/license error:', error);
    return NextResponse.json({ error: 'Failed to delete license key' }, { status: 500 });
  }
}