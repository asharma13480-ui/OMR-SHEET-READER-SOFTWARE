import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

function generateKey(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const seg = () =>
    Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `DT-${seg()}-${seg()}-${seg()}`;
}

// POST /api/license/admin-init — auto-create admin lifetime license on first boot
export async function POST() {
  try {
    // Check if any license keys already exist
    const existingCount = await db.licenseKey.count();

    // If keys already exist, don't auto-create (admin already set up)
    if (existingCount > 0) {
      // Find the first lifetime or active key for admin
      const adminKey = await db.licenseKey.findFirst({
        where: {
          OR: [
            { type: 'lifetime', status: 'active' },
            { type: 'lifetime', status: 'unused' },
          ],
        },
      });

      if (adminKey) {
        return NextResponse.json({ key: adminKey.key, type: adminKey.type, autoCreated: false });
      }

      // No lifetime key found — return existing first key
      const firstKey = await db.licenseKey.findFirst({ orderBy: { createdAt: 'asc' } });
      if (firstKey) {
        return NextResponse.json({ key: firstKey.key, type: firstKey.type, autoCreated: false });
      }

      return NextResponse.json({ error: 'No license keys available' }, { status: 404 });
    }

    // First boot — create a lifetime admin license
    let key: string;
    let exists = true;
    let attempts = 0;
    do {
      key = generateKey();
      const found = await db.licenseKey.findUnique({ where: { key } });
      if (!found) exists = false;
      attempts++;
    } while (exists && attempts < 10);

    await db.licenseKey.create({
      data: {
        key,
        type: 'lifetime',
        status: 'unused',
        activatedBy: 'admin-auto',
      },
    });

    return NextResponse.json({ key, type: 'lifetime', autoCreated: true });
  } catch (error) {
    console.error('POST /api/license/admin-init error:', error);
    return NextResponse.json({ error: 'Failed to initialize admin license' }, { status: 500 });
  }
}
