import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/license/validate — validate a license key
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { key } = body;

    if (!key) {
      return NextResponse.json({ valid: false, error: 'License key is required' });
    }

    const license = await db.licenseKey.findUnique({ where: { key: key.trim().toUpperCase() } });

    if (!license) {
      return NextResponse.json({ valid: false, error: 'License key not found' });
    }

    if (license.status === 'revoked') {
      return NextResponse.json({ valid: false, error: 'License key has been revoked' });
    }

    if (license.status === 'unused') {
      return NextResponse.json({ valid: false, error: 'License key has not been activated' });
    }

    if (license.status === 'expired') {
      return NextResponse.json({ valid: false, error: 'License key has expired' });
    }

    // Active - check expiration
    const now = new Date();
    if (license.expiresAt && license.expiresAt < now) {
      // Update status to expired
      await db.licenseKey.update({
        where: { id: license.id },
        data: { status: 'expired' },
      });
      return NextResponse.json({ valid: false, error: 'License key has expired' });
    }

    const daysRemaining = license.expiresAt
      ? Math.max(0, Math.ceil((license.expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
      : Infinity;

    return NextResponse.json({
      valid: true,
      type: license.type,
      expiresAt: license.expiresAt,
      activatedAt: license.activatedAt,
      daysRemaining,
    });
  } catch (error) {
    console.error('POST /api/license/validate error:', error);
    return NextResponse.json({ valid: false, error: 'Validation failed' }, { status: 500 });
  }
}