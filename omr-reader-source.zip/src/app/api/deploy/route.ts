import { NextResponse } from 'next/server';
import { execSync } from 'child_process';
import { existsSync, mkdirSync, rmSync, writeFileSync, readFileSync } from 'fs';
import { join } from 'path';
import { readdirSync, statSync, copyFileSync } from 'fs';

const TMP_DIR = '/tmp/omr-deploy-build';
const FILES_TO_INCLUDE = [
  'package.json',
  'next.config.ts',
  'tsconfig.json',
  'postcss.config.mjs',
  'tailwind.config.ts',
  'eslint.config.mjs',
  'components.json',
  '.gitignore',
  'bun.lock',
];
const DIRS_TO_INCLUDE = ['prisma', 'src', 'public'];

function copyDirRecursive(src: string, dest: string, excludePatterns: string[]) {
  if (!existsSync(dest)) mkdirSync(dest, { recursive: true });
  const entries = readdirSync(src);
  for (const entry of entries) {
    const srcPath = join(src, entry);
    const destPath = join(dest, entry);
    if (statSync(srcPath).isDirectory()) {
      copyDirRecursive(srcPath, destPath, excludePatterns);
    } else {
      const shouldExclude = excludePatterns.some(p => entry.endsWith(p));
      if (!shouldExclude) {
        copyFileSync(srcPath, destPath);
      }
    }
  }
}

export async function GET() {
  try {
    const projectRoot = process.cwd();

    // Clean and create temp dir
    if (existsSync(TMP_DIR)) rmSync(TMP_DIR, { recursive: true });
    mkdirSync(TMP_DIR, { recursive: true });

    // Copy individual files
    for (const file of FILES_TO_INCLUDE) {
      const src = join(projectRoot, file);
      if (existsSync(src)) copyFileSync(src, join(TMP_DIR, file));
    }

    // Copy directories
    const excludeExts = ['.log', '.bak', '.png'];
    for (const dir of DIRS_TO_INCLUDE) {
      const src = join(projectRoot, dir);
      const dest = join(TMP_DIR, dir);
      if (existsSync(src)) {
        copyDirRecursive(src, dest, excludeExts);
      }
    }

    // Copy public PNGs (icons etc)
    const publicPngs = ['logo.png', 'logo.svg', 'icon-192.png', 'icon-512.png', 'icon-1024.png', 'manifest.json', 'sw.js', 'robots.txt', 'offline.html'];
    for (const f of publicPngs) {
      const src = join(projectRoot, 'public', f);
      if (existsSync(src)) {
        const destDir = join(TMP_DIR, 'public');
        if (!existsSync(destDir)) mkdirSync(destDir, { recursive: true });
        copyFileSync(src, join(destDir, f));
      }
    }

    // Create .env.example
    writeFileSync(join(TMP_DIR, '.env.example'), 
`# Local / VPS deployment (SQLite file)
DATABASE_URL=file:./db/custom.db

# Vercel deployment (Turso Cloud SQLite)
# DATABASE_URL=libsql://omr-reader-yourname.turso.io
# TURSO_AUTH_TOKEN=your-turso-auth-token-here
`);

    // Create deploy script for VPS
    writeFileSync(join(TMP_DIR, 'deploy-vps.sh'), `#!/bin/bash
echo "=== OMR Sheet Reader - VPS Deploy ==="

# Install dependencies
echo "[1/5] Installing dependencies..."
bun install

# Setup database
echo "[2/5] Setting up database..."
mkdir -p db
bun run db:push

# Build
echo "[3/5] Building application..."
bun run build

# Stop old process
echo "[4/5] Restarting server..."
pm2 delete omr-reader 2>/dev/null || true

# Start new
pm2 start bun --name "omr-reader" -- start
pm2 save

echo "[5/5] Done! App running on port 3000"
echo "Configure Nginx + SSL for your domain (see Help page)"
`);

    // Create vercel.json for proper Vercel deployment
    writeFileSync(join(TMP_DIR, 'vercel.json'), JSON.stringify({
      framework: "nextjs",
      buildCommand: "npx prisma generate && npx prisma db push && next build",
      installCommand: "npm install",
      outputDirectory: ".next",
    }, null, 2));

    // Create the zip
    execSync(`cd ${TMP_DIR} && zip -r /tmp/omr-reader-source.zip . -x "*.log" "*.bak"`);

    // Read the zip file
    const zipBuffer = readFileSync('/tmp/omr-reader-source.zip');

    // Cleanup
    rmSync(TMP_DIR, { recursive: true });

    return new NextResponse(zipBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="omr-reader-source.zip"',
      },
    });
  } catch (error) {
    console.error('Error creating deploy package:', error);
    return NextResponse.json({ error: 'Failed to create deploy package' }, { status: 500 });
  }
}