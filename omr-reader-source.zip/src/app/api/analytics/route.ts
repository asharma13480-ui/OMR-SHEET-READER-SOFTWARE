import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 });
    }

    const results = await db.result.findMany({
      where: { examId },
      orderBy: { obtainedMarks: 'desc' },
    });

    const answerKeys = await db.answerKey.findMany({
      where: { examId },
      orderBy: { questionNo: 'asc' },
    });

    // Summary
    const totalStudents = results.length;
    const passCount = results.filter((r) => r.status === 'pass').length;
    const failCount = totalStudents - passCount;
    const scores = results.map((r) => Number(r.obtainedMarks));
    const averageScore = totalStudents > 0 ? scores.reduce((a, b) => a + b, 0) / totalStudents : 0;
    const highestScore = totalStudents > 0 ? Math.max(...scores) : 0;
    const lowestScore = totalStudents > 0 ? Math.min(...scores) : 0;
    const passRate = totalStudents > 0 ? (passCount / totalStudents) * 100 : 0;

    // Median
    const sortedScores = [...scores].sort((a, b) => a - b);
    const median = totalStudents > 0
      ? totalStudents % 2 === 0
        ? (sortedScores[totalStudents / 2 - 1] + sortedScores[totalStudents / 2]) / 2
        : sortedScores[Math.floor(totalStudents / 2)]
      : 0;

    // Standard Deviation
    const variance = totalStudents > 0
      ? scores.reduce((sum, score) => sum + Math.pow(score - averageScore, 2), 0) / totalStudents
      : 0;
    const standardDeviation = Math.sqrt(variance);

    // Score distribution
    const totalMarks = Number(exam.totalMarks) || 100;
    const bucketSize = Math.ceil(totalMarks / 10);
    const distribution: { range: string; count: number }[] = [];
    for (let i = 0; i < 10; i++) {
      const min = i * bucketSize;
      const max = Math.min((i + 1) * bucketSize, totalMarks);
      const count = scores.filter((s) => s >= min && s < (i === 9 ? max + 1 : max)).length;
      distribution.push({ range: `${min}-${max}`, count });
    }

    // Pass vs Fail
    const passFail = [
      { status: 'Pass', count: passCount },
      { status: 'Fail', count: failCount },
    ];

    // Performance trend (by rank order)
    const performanceTrend = results
      .sort((a, b) => Number(a.obtainedMarks) - Number(b.obtainedMarks))
      .map((r, idx) => ({
        index: `#${idx + 1}`,
        score: Number(r.obtainedMarks),
      }));

    // Question analysis
    const totalCorrectPerQ: Record<number, number> = {};
    const totalIncorrectPerQ: Record<number, number> = {};
    const totalUnansweredPerQ: Record<number, number> = {};

    for (const ak of answerKeys) {
      totalCorrectPerQ[ak.questionNo] = 0;
      totalIncorrectPerQ[ak.questionNo] = 0;
      totalUnansweredPerQ[ak.questionNo] = 0;
    }

    // Analyze OMR sheets against answer keys
    const omrSheets = await db.oMRSheet.findMany({
      where: { examId },
    });

    for (const sheet of omrSheets) {
      const answers: string[] = JSON.parse(sheet.answers);
      for (const ak of answerKeys) {
        const studentAnswer = answers[ak.questionNo - 1];
        if (!studentAnswer || studentAnswer === '-' || studentAnswer === '') {
          totalUnansweredPerQ[ak.questionNo]++;
        } else if (studentAnswer.toUpperCase() === ak.correctAnswer.toUpperCase()) {
          totalCorrectPerQ[ak.questionNo]++;
        } else {
          totalIncorrectPerQ[ak.questionNo]++;
        }
      }
    }

    const questions = answerKeys.map((ak) => {
      const total = totalCorrectPerQ[ak.questionNo] + totalIncorrectPerQ[ak.questionNo] + totalUnansweredPerQ[ak.questionNo];
      const accuracy = total > 0 ? (totalCorrectPerQ[ak.questionNo] / total) * 100 : 0;
      let difficulty = 'medium';
      if (accuracy >= 70) difficulty = 'easy';
      else if (accuracy < 40) difficulty = 'hard';

      return {
        questionNo: ak.questionNo,
        correctAnswer: ak.correctAnswer,
        totalCorrect: totalCorrectPerQ[ak.questionNo],
        totalIncorrect: totalIncorrectPerQ[ak.questionNo],
        totalUnanswered: totalUnansweredPerQ[ak.questionNo],
        difficulty,
      };
    });

    // Student reports
    const students = results
      .sort((a, b) => Number(b.obtainedMarks) - Number(a.obtainedMarks))
      .map((r, idx) => ({
        rank: idx + 1,
        studentName: r.studentName,
        rollNumber: r.rollNumber,
        obtainedMarks: Number(r.obtainedMarks),
        totalMarks: Number(r.totalMarks),
        correctCount: r.correctCount,
        incorrectCount: r.incorrectCount,
        unansweredCount: r.unansweredCount,
        negativeMarks: Number(r.negativeMarks),
        percentage: Number(r.percentage),
        status: r.status,
      }));

    // Total answer stats
    const totalCorrect = results.reduce((sum, r) => sum + r.correctCount, 0);
    const totalIncorrect = results.reduce((sum, r) => sum + r.incorrectCount, 0);
    const totalUnanswered = results.reduce((sum, r) => sum + r.unansweredCount, 0);

    const summary = {
      totalStudents,
      passCount,
      failCount,
      averageScore: Math.round(averageScore * 100) / 100,
      highestScore: Math.round(highestScore * 100) / 100,
      lowestScore: Math.round(lowestScore * 100) / 100,
      passRate: Math.round(passRate * 100) / 100,
      medianScore: Math.round(median * 100) / 100,
      standardDeviation: Math.round(standardDeviation * 100) / 100,
      averagePercentage: Math.round((averageScore / totalMarks) * 10000) / 100,
      totalCorrect,
      totalIncorrect,
      totalUnanswered,
    };

    const detailedStats = [
      { metric: 'Total Students', value: totalStudents, description: 'Students evaluated in this exam' },
      { metric: 'Average Score', value: summary.averageScore.toFixed(2), description: 'Mean score across all students' },
      { metric: 'Median Score', value: summary.medianScore.toFixed(2), description: 'Middle value of all scores' },
      { metric: 'Highest Score', value: summary.highestScore.toFixed(2), description: 'Best performance in the exam' },
      { metric: 'Lowest Score', value: summary.lowestScore.toFixed(2), description: 'Lowest performance in the exam' },
      { metric: 'Standard Deviation', value: summary.standardDeviation.toFixed(2), description: 'Spread of scores around the mean' },
      { metric: 'Pass Rate', value: `${summary.passRate.toFixed(1)}%`, description: `Percentage of students passing (${passCount}/${totalStudents})` },
      { metric: 'Total Correct', value: totalCorrect, description: 'Total correct answers across all students' },
      { metric: 'Total Incorrect', value: totalIncorrect, description: 'Total incorrect answers across all students' },
      { metric: 'Total Unanswered', value: totalUnanswered, description: 'Total unanswered questions across all students' },
    ];

    return NextResponse.json({
      summary,
      scoreDistribution: distribution,
      passFail,
      performanceTrend,
      detailedStats,
      students,
      questions,
    });
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json(
      {
        summary: { totalStudents: 0, passCount: 0, failCount: 0, averageScore: 0, highestScore: 0, lowestScore: 0, passRate: 0, medianScore: 0, standardDeviation: 0 },
        scoreDistribution: [],
        passFail: [],
        performanceTrend: [],
        detailedStats: [],
        students: [],
        questions: [],
      },
      { status: 500 }
    );
  }
}
