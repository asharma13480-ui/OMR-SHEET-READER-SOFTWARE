import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');
    const type = searchParams.get('type') || 'results';

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    if (type === 'results') {
      const results = await db.result.findMany({
        where: { examId },
        orderBy: { obtainedMarks: 'desc' },
      });
      return NextResponse.json({ results });
    }

    if (type === 'answer-key') {
      const answerKeys = await db.answerKey.findMany({
        where: { examId },
        orderBy: { questionNo: 'asc' },
      });
      return NextResponse.json({ answerKeys });
    }

    return NextResponse.json({ error: 'Invalid export type' }, { status: 400 });
  } catch (error) {
    console.error('Error in export:', error);
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
