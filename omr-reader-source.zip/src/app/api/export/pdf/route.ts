import { NextResponse } from 'next/server';
import { PDFDocument, PDFPage, rgb, StandardFonts, PageSizes } from 'pdf-lib';
import { db } from '@/lib/db';
import { readFileSync } from 'fs';
import { join } from 'path';

/* ------------------------------------------------------------------ */
/*  Colour helpers (pdf-lib uses 0-1 range)                            */
/* ------------------------------------------------------------------ */

const GREEN_MAIN   = rgb(0, 0.5, 0);
const GREEN_DARK   = rgb(0, 0.33, 0);
const GREEN_LIGHT  = rgb(0.91, 0.96, 0.91);
const GREEN_ACCENT = rgb(0.69, 0.82, 0.13);
const RED_COLOR    = rgb(0.8, 0, 0);
const GOLD_COLOR   = rgb(0.85, 0.65, 0.13);
const GRAY_MED     = rgb(0.55, 0.55, 0.55);
const GRAY_LIGHT   = rgb(0.88, 0.92, 0.88);
const WHITE         = rgb(1, 1, 1);
const BLACK         = rgb(0, 0, 0);
const TABLE_BG     = rgb(0.96, 0.98, 0.96);

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function formatDate(d: string | null): string {
  if (!d) return 'N/A';
  try {
    return new Date(d).toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return d;
  }
}

function generateNow(): string {
  return new Date().toLocaleString('en-IN', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}

function truncate(str: string, max: number): string {
  if (str.length <= max) return str;
  return str.substring(0, max - 2) + '..';
}

/* ------------------------------------------------------------------ */
/*  GET handler                                                        */
/* ------------------------------------------------------------------ */

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');
    const includeLogo = searchParams.get('includeLogo') !== 'false';
    const includeSummary = searchParams.get('includeSummary') !== 'false';
    const paperSize = searchParams.get('paperSize') || 'A4';

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    /* ---------- Fetch data ---------- */
    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 });
    }

    const results = await db.result.findMany({
      where: { examId },
      orderBy: { obtainedMarks: 'desc' },
    });

    // Assign ranks if they aren't already set
    results.forEach((r, idx) => {
      if (r.rank === null || r.rank === undefined) {
        Object.assign(r, { rank: idx + 1 });
      }
    });

    if (results.length === 0) {
      return NextResponse.json(
        { error: 'No results found for this exam' },
        { status: 404 },
      );
    }

    /* ---------- Create PDF ---------- */
    const pageSize = paperSize === 'LEGAL' ? PageSizes.Legal : PageSizes.A4;
    const pdfDoc = await PDFDocument.create();

    const [fontRegular, fontBold, fontItalic] = await Promise.all([
      pdfDoc.embedFont(StandardFonts.Helvetica),
      pdfDoc.embedFont(StandardFonts.HelveticaBold),
      pdfDoc.embedFont(StandardFonts.HelveticaOblique),
    ]);

    let logoImage: Parameters<PDFPage['drawImage']>[0] | null = null;
    try {
      const logoBuffer = readFileSync(join(process.cwd(), 'public', 'logo.png'));
      logoImage = await pdfDoc.embedPng(logoBuffer);
    } catch {
      // Logo not available — continue without it
    }

    const pageWidth = pageSize[0];
    const pageHeight = pageSize[1];
    const margin = 40;
    const contentWidth = pageWidth - margin * 2;

    /* ================================================================
       PAGE 1: COVER PAGE
    ================================================================ */
    const coverPage = pdfDoc.addPage(pageSize);

    // Outer green border
    coverPage.drawRectangle({
      x: margin - 8,
      y: margin - 8,
      width: contentWidth + 16,
      height: pageHeight - margin * 2 + 16,
      borderColor: GREEN_MAIN,
      borderWidth: 4,
      color: WHITE,
    });

    // Inner green accent border
    coverPage.drawRectangle({
      x: margin - 2,
      y: margin - 2,
      width: contentWidth + 4,
      height: pageHeight - margin * 2 + 4,
      borderColor: GREEN_ACCENT,
      borderWidth: 1,
      color: WHITE,
    });

    let currentY = pageHeight - margin - 20;

    // Logo
    if (logoImage && includeLogo) {
      const logoSize = 90;
      const logoX = (pageWidth - logoSize) / 2;
      coverPage.drawImage(logoImage, {
        x: logoX,
        y: currentY - logoSize,
        width: logoSize,
        height: logoSize,
      });
      currentY -= logoSize + 15;
    } else {
      currentY -= 40;
    }

    // App name
    const appName = 'OMR SHEET READER';
    const appNameW = fontBold.widthOfTextAtSize(appName, 18);
    coverPage.drawText(appName, {
      x: (pageWidth - appNameW) / 2,
      y: currentY,
      size: 18,
      font: fontBold,
      color: GREEN_MAIN,
    });
    currentY -= 25;

    // Divider
    const divW = contentWidth * 0.6;
    const divX = (pageWidth - divW) / 2;
    coverPage.drawRectangle({ x: divX, y: currentY, width: divW, height: 1.5, color: GREEN_MAIN });
    currentY -= 20;

    // Title
    const titleText = 'EXAMINATION RESULT REPORT';
    const titleW = fontBold.widthOfTextAtSize(titleText, 14);
    coverPage.drawText(titleText, {
      x: (pageWidth - titleW) / 2,
      y: currentY,
      size: 14,
      font: fontBold,
      color: GREEN_DARK,
    });
    currentY -= 22;

    // Exam name
    const examLabel = exam.name.length > 40 ? exam.name.substring(0, 38) + '...' : exam.name;
    const examLabelW = fontBold.widthOfTextAtSize(examLabel, 22);
    coverPage.drawText(examLabel, {
      x: (pageWidth - examLabelW) / 2,
      y: currentY,
      size: 22,
      font: fontBold,
      color: BLACK,
    });
    currentY -= 28;

    // Divider
    coverPage.drawRectangle({ x: divX, y: currentY, width: divW, height: 1.5, color: GREEN_MAIN });
    currentY -= 30;

    // Details
    const details: [string, string][] = [
      ['Subject', exam.subject || 'N/A'],
      ['Date of Examination', formatDate(exam.date)],
      ['Duration', exam.duration || 'N/A'],
      ['Total Questions', String(exam.totalQuestions)],
      ['Total Marks', String(exam.totalMarks)],
      ['Passing Percentage', `${exam.passingPercent}%`],
      ['Negative Marking', exam.negativeMarking > 0 ? `${exam.negativeMarking} per wrong answer` : 'None'],
      ['Total Students', String(results.length)],
    ];

    const tableLeft = pageWidth / 2 - 140;
    for (const [label, value] of details) {
      coverPage.drawText(label, { x: tableLeft, y: currentY, size: 10, font: fontBold, color: GREEN_DARK });
      coverPage.drawRectangle({ x: tableLeft, y: currentY - 4, width: 280, height: 0.5, color: GRAY_LIGHT });
      coverPage.drawText(value, { x: tableLeft + 155, y: currentY, size: 10, font: fontRegular, color: BLACK });
      currentY -= 18;
    }

    currentY -= 15;
    coverPage.drawRectangle({ x: divX, y: currentY, width: divW, height: 1.5, color: GREEN_MAIN });
    currentY -= 20;

    // Generated date
    const genText = `Report Generated: ${generateNow()}`;
    const genTextW = fontItalic.widthOfTextAtSize(genText, 9);
    coverPage.drawText(genText, {
      x: (pageWidth - genTextW) / 2,
      y: currentY,
      size: 9,
      font: fontItalic,
      color: GRAY_MED,
    });
    currentY -= 25;

    // Confidential
    const confText = 'CONFIDENTIAL - For Authorised Personnel Only';
    const confW = fontBold.widthOfTextAtSize(confText, 8);
    const confBoxX = (pageWidth - confW) / 2 - 8;
    coverPage.drawRectangle({
      x: confBoxX, y: currentY - 3, width: confW + 16, height: 16,
      borderColor: RED_COLOR, borderWidth: 0.8, color: WHITE,
    });
    coverPage.drawText(confText, { x: confBoxX + 8, y: currentY, size: 8, font: fontBold, color: RED_COLOR });

    /* ================================================================
       PAGE 2+: RESULTS TABLE
    ================================================================ */
    const resultsPage = pdfDoc.addPage(pageSize);
    let yPos = pageHeight - margin;
    const fontSize = 8.5;
    const headerFontSize = 7.5;
    const cellPad = 4;

    // Page header
    if (logoImage && includeLogo) {
      resultsPage.drawImage(logoImage, { x: margin, y: yPos - 28, width: 28, height: 28 });
    }

    const hdrAppName = 'OMR Sheet Reader';
    resultsPage.drawText(hdrAppName, {
      x: pageWidth - margin - fontBold.widthOfTextAtSize(hdrAppName, 10),
      y: yPos - 8, size: 10, font: fontBold, color: GREEN_MAIN,
    });
    yPos -= 14;

    const hdrTitle = `Examination Result Report - ${exam.name}`;
    resultsPage.drawText(hdrTitle.length > 80 ? hdrTitle.substring(0, 78) + '...' : hdrTitle, {
      x: (logoImage && includeLogo) ? margin + 36 : margin,
      y: yPos - 4, size: 12, font: fontBold, color: GREEN_DARK,
    });
    yPos -= 16;

    if (exam.subject) {
      const subLine = `Subject: ${exam.subject}  |  Date: ${formatDate(exam.date)}  |  Total Marks: ${exam.totalMarks}`;
      resultsPage.drawText(subLine, {
        x: (logoImage && includeLogo) ? margin + 36 : margin,
        y: yPos - 2, size: 8.5, font: fontRegular, color: GRAY_MED,
      });
      yPos -= 12;
    }

    // Header divider
    resultsPage.drawRectangle({ x: margin, y: yPos, width: contentWidth, height: 2, color: GREEN_MAIN });
    yPos -= 14;

    /* ---- Summary stats ---- */
    if (includeSummary) {
      const totalStudents = results.length;
      const passCount = results.filter((r) => r.status === 'pass').length;
      const failCount = totalStudents - passCount;
      const avgPct = (results.reduce((s, r) => s + r.percentage, 0) / totalStudents).toFixed(1);
      const highestScore = results[0].obtainedMarks;
      const lowestScore = results[results.length - 1].obtainedMarks;
      const passRate = ((passCount / totalStudents) * 100).toFixed(1);

      const summaryBoxes: { label: string; value: string; bg: ReturnType<typeof rgb> }[] = [
        { label: 'Total Students', value: String(totalStudents), bg: GREEN_LIGHT },
        { label: 'Passed', value: String(passCount), bg: GREEN_LIGHT },
        { label: 'Failed', value: String(failCount), bg: rgb(0.99, 0.91, 0.91) },
        { label: 'Avg Score', value: `${avgPct}%`, bg: GREEN_LIGHT },
        { label: 'Highest', value: String(highestScore), bg: rgb(1, 0.97, 0.88) },
        { label: 'Pass Rate', value: `${passRate}%`, bg: GREEN_LIGHT },
      ];

      const boxW = (contentWidth - 25) / 6;
      const boxH = 36;

      summaryBoxes.forEach((box, i) => {
        const bx = margin + i * (boxW + 5);
        const activePage = pdfDoc.getPages()[pdfDoc.getPageCount() - 1];
        activePage.drawRectangle({
          x: bx, y: yPos - boxH, width: boxW, height: boxH,
          color: box.bg, borderColor: GRAY_LIGHT, borderWidth: 0.5,
        });
        const valW = fontBold.widthOfTextAtSize(box.value, 13);
        activePage.drawText(box.value, {
          x: bx + (boxW - valW) / 2, y: yPos - 20, size: 13, font: fontBold, color: GREEN_DARK,
        });
        const lblW = fontRegular.widthOfTextAtSize(box.label, 6);
        activePage.drawText(box.label.toUpperCase(), {
          x: bx + (boxW - lblW) / 2, y: yPos - 30, size: 6, font: fontRegular, color: GRAY_MED,
        });
      });

      yPos -= boxH + 10;
    }

    /* ---- Table column definitions ---- */
    const columns = [
      { header: 'Rank', width: 38 },
      { header: 'Roll No.', width: 60 },
      { header: 'Student Name', width: 120 },
      { header: 'Marks', width: 65 },
      { header: 'Total', width: 40 },
      { header: '%', width: 45 },
      { header: 'Correct', width: 42 },
      { header: 'Wrong', width: 38 },
      { header: 'Unans.', width: 38 },
      { header: 'Neg.', width: 38 },
      { header: 'Status', width: 42 },
    ];

    const usedWidth = columns.reduce((s, c) => s + c.width, 0);
    columns[2].width += contentWidth - usedWidth;

    // Draw table header
    function drawTableHeader(page: PDFPage, y: number): number {
      let cx = margin;
      page.drawRectangle({ x: margin, y: y - 16, width: contentWidth, height: 16, color: GREEN_MAIN });
      for (const col of columns) {
        page.drawText(col.header.toUpperCase(), {
          x: cx + cellPad, y: y - 12, size: headerFontSize, font: fontBold, color: WHITE,
        });
        cx += col.width;
      }
      return y - 16;
    }

    // Draw page footer
    function drawFooter(page: PDFPage) {
      const fy = margin - 10;
      const leftText = 'Generated by OMR Sheet Reader';
      const rightText = generateNow();
      const centerText = `— ${exam.name} —`;

      page.drawRectangle({
        x: margin, y: fy + 10, width: pageWidth - margin * 2, height: 0.5, color: GRAY_LIGHT,
      });
      page.drawText(leftText, { x: margin, y: fy, size: 7, font: fontItalic, color: GRAY_MED });
      const rw = fontItalic.widthOfTextAtSize(rightText, 7);
      page.drawText(rightText, { x: pageWidth - margin - rw, y: fy, size: 7, font: fontItalic, color: GRAY_MED });
      const cw = fontItalic.widthOfTextAtSize(centerText, 7);
      page.drawText(centerText, { x: (pageWidth - cw) / 2, y: fy, size: 7, font: fontItalic, color: GRAY_MED });
    }

    // Draw page header for continuation pages
    function drawPageHeader(page: PDFPage): number {
      let py = pageHeight - margin;
      if (logoImage && includeLogo) {
        page.drawImage(logoImage, { x: margin, y: py - 28, width: 28, height: 28 });
      }
      page.drawText(hdrAppName, {
        x: pageWidth - margin - fontBold.widthOfTextAtSize(hdrAppName, 10),
        y: py - 8, size: 10, font: fontBold, color: GREEN_MAIN,
      });
      py -= 14;

      const contTitle = `${exam.name} — Results (continued)`;
      page.drawText(contTitle, {
        x: (logoImage && includeLogo) ? margin + 36 : margin,
        y: py - 4, size: 11, font: fontBold, color: GREEN_DARK,
      });
      py -= 16;

      page.drawRectangle({ x: margin, y: py, width: contentWidth, height: 2, color: GREEN_MAIN });
      return py - 14;
    }

    // Draw table header on given page
    yPos = drawTableHeader(resultsPage, yPos);

    // Table rows
    const rowHeight = 14;
    const maxY = margin + 40;
    const headerBlockHeight = 16;
    let currentResultsPage = resultsPage;
    let rowsOnPage = 0;
    const maxRowsPerPage = Math.floor((pageHeight - margin * 2 - 90) / rowHeight);

    for (let i = 0; i < results.length; i++) {
      const r = results[i];

      // Check if we need a new page
      if (i > 0 && rowsOnPage >= maxRowsPerPage) {
        drawFooter(currentResultsPage);
        const newPage = pdfDoc.addPage(pageSize);
        currentResultsPage = newPage;
        yPos = drawPageHeader(newPage);
        yPos = drawTableHeader(newPage, yPos);
        rowsOnPage = 0;
      }

      // Alternating row bg
      if (rowsOnPage % 2 === 0) {
        currentResultsPage.drawRectangle({
          x: margin, y: yPos - rowHeight, width: contentWidth, height: rowHeight, color: TABLE_BG,
        });
      }

      // Topper highlight
      if (r.rank === 1) {
        currentResultsPage.drawRectangle({
          x: margin, y: yPos - rowHeight, width: contentWidth, height: rowHeight,
          borderColor: GOLD_COLOR, borderWidth: 1.2, color: rgb(1, 0.99, 0.87),
        });
      } else if (r.status === 'fail') {
        currentResultsPage.drawRectangle({
          x: margin, y: yPos - rowHeight, width: contentWidth, height: rowHeight,
          color: rgb(0.99, 0.93, 0.93),
        });
      }

      // Cell data
      const rankStr = r.rank ? String(r.rank) : '-';
      const cells: { text: string; bold: boolean; color: ReturnType<typeof rgb> }[] = [
        { text: rankStr, bold: true, color: BLACK },
        { text: r.rollNumber, bold: false, color: BLACK },
        { text: truncate(r.studentName, 22), bold: true, color: BLACK },
        { text: String(r.obtainedMarks), bold: true, color: BLACK },
        { text: String(r.totalMarks), bold: false, color: GRAY_MED },
        { text: `${r.percentage.toFixed(1)}%`, bold: false, color: BLACK },
        { text: String(r.correctCount), bold: false, color: rgb(0, 0.4, 0) },
        { text: String(r.incorrectCount), bold: false, color: RED_COLOR },
        { text: String(r.unansweredCount), bold: false, color: GRAY_MED },
        { text: r.negativeMarks > 0 ? `-${r.negativeMarks}` : '0', bold: false, color: r.negativeMarks > 0 ? RED_COLOR : GRAY_MED },
        { text: r.status === 'pass' ? 'PASS' : 'FAIL', bold: true, color: r.status === 'pass' ? rgb(0, 0.4, 0) : RED_COLOR },
      ];

      let cx = margin;
      for (let ci = 0; ci < columns.length; ci++) {
        const colW = columns[ci].width;
        const cell = cells[ci];
        const cellW = fontRegular.widthOfTextAtSize(cell.text, fontSize);
        // Center align
        const tx = cx + (colW - cellW) / 2;

        currentResultsPage.drawText(cell.text, {
          x: tx, y: yPos - 10, size: fontSize,
          font: cell.bold ? fontBold : fontRegular,
          color: cell.color,
        });
        cx += colW;
      }

      // Row border
      currentResultsPage.drawRectangle({
        x: margin, y: yPos - rowHeight, width: contentWidth, height: 0.3, color: GRAY_LIGHT,
      });

      yPos -= rowHeight;
      rowsOnPage++;
    }

    // Summary row at bottom
    const lastActivePage = pdfDoc.getPages()[pdfDoc.getPageCount() - 1];
    yPos -= 4;
    const totalStudents = results.length;
    const passCount = results.filter((r) => r.status === 'pass').length;
    const failCount = totalStudents - passCount;
    const avgPct = (results.reduce((s, r) => s + r.percentage, 0) / totalStudents).toFixed(1);
    const highestScore = results[0].obtainedMarks;
    const lowestScore = results[results.length - 1].obtainedMarks;

    const summaryText = `Total: ${totalStudents}  |  Pass: ${passCount}  |  Fail: ${failCount}  |  Avg: ${avgPct}%  |  Highest: ${highestScore}  |  Lowest: ${lowestScore}`;
    lastActivePage.drawRectangle({
      x: margin, y: yPos - 16, width: contentWidth, height: 16,
      color: GREEN_LIGHT, borderColor: GREEN_MAIN, borderWidth: 0.5,
    });
    const stW = fontBold.widthOfTextAtSize(summaryText, 7.5);
    lastActivePage.drawText(summaryText, {
      x: (pageWidth - stW) / 2, y: yPos - 12, size: 7.5, font: fontBold, color: GREEN_DARK,
    });

    // Page footer
    drawFooter(lastActivePage);

    /* ---------- Serialize & return ---------- */
    const pdfBytes = await pdfDoc.save();
    const filename = `${exam.name.replace(/[^a-zA-Z0-9]/g, '_')}_Results.pdf`;

    return new NextResponse(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': String(pdfBytes.length),
      },
    });
  } catch (error) {
    console.error('PDF generation error:', error);
    return NextResponse.json(
      { error: 'Failed to generate PDF. Please try again.' },
      { status: 500 },
    );
  }
}
