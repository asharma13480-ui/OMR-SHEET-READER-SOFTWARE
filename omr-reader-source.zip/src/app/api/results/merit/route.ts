import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    const results = await db.result.findMany({
      where: { examId },
      orderBy: { obtainedMarks: 'desc' },
    });

    // Assign ranks
    const ranked = results.map((r, idx) => ({
      ...r,
      rank: idx + 1,
      negativeMarks: Number(r.negativeMarks),
      percentage: Number(r.percentage),
      obtainedMarks: Number(r.obtainedMarks),
      totalMarks: Number(r.totalMarks),
      correctCount: r.correctCount,
      incorrectCount: r.incorrectCount,
      unansweredCount: r.unansweredCount,
    }));

    // Handle ties: same score = same rank
    for (let i = 1; i < ranked.length; i++) {
      if (ranked[i].obtainedMarks === ranked[i - 1].obtainedMarks) {
        ranked[i].rank = ranked[i - 1].rank;
      }
    }

    return NextResponse.json({ students: ranked });
  } catch (error) {
    console.error('Error fetching merit list:', error);
    return NextResponse.json({ students: [] }, { status: 500 });
  }
}
