import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/results?examId=xxx[&omrSheetId=xxx] — get results for an exam
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const examId = searchParams.get('examId');
    const omrSheetId = searchParams.get('omrSheetId');

    const results = await db.result.findMany({
      where: examId ? { examId } : undefined,
      orderBy: [{ rank: 'asc' }, { obtainedMarks: 'desc' }],
    });

    // If omrSheetId is provided, also return answer comparison
    if (omrSheetId) {
      const omrSheet = await db.oMRSheet.findUnique({
        where: { id: omrSheetId },
      });
      const answerKey = await db.answerKey.findMany({
        where: { examId },
        orderBy: { questionNo: 'asc' },
      });

      if (omrSheet && answerKey.length > 0) {
        const studentAnswers: string[] = JSON.parse(omrSheet.answers);
        const comparison = answerKey.map((ak) => {
          const studentAns = studentAnswers[ak.questionNo - 1] || '';
          return {
            questionNo: ak.questionNo,
            correctAnswer: ak.correctAnswer,
            studentAnswer: studentAns,
            marks: ak.marks,
            isCorrect: studentAns.toUpperCase() === ak.correctAnswer.toUpperCase(),
            isUnanswered: !studentAns || studentAns === '',
          };
        });
        return NextResponse.json({ results, comparison });
      }
    }

    return NextResponse.json({ results });
  } catch (error) {
    console.error('GET /api/results error:', error);
    return NextResponse.json({ error: 'Failed to fetch results' }, { status: 500 });
  }
}

// POST /api/results — process all pending OMR sheets for an exam
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { examId } = body;

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    // Fetch exam info
    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json({ error: 'Exam not found' }, { status: 404 });
    }

    // Fetch answer key
    const answerKey = await db.answerKey.findMany({
      where: { examId },
      orderBy: { questionNo: 'asc' },
    });

    if (answerKey.length === 0) {
      return NextResponse.json(
        { error: 'No answer key found for this exam. Please upload answer key first.' },
        { status: 400 }
      );
    }

    // Build answer key map
    const answerKeyMap = new Map<number, { answer: string; marks: number }>();
    for (const ak of answerKey) {
      answerKeyMap.set(ak.questionNo, { answer: ak.correctAnswer.toUpperCase(), marks: ak.marks });
    }

    // Fetch pending OMR sheets
    const pendingSheets = await db.oMRSheet.findMany({
      where: { examId, status: 'pending' },
    });

    if (pendingSheets.length === 0) {
      return NextResponse.json({ message: 'No pending sheets to process', processed: 0 });
    }

    let processed = 0;
    const allResults: Array<{
      examId: string;
      omrSheetId: string;
      studentName: string;
      rollNumber: string;
      totalMarks: number;
      obtainedMarks: number;
      correctCount: number;
      incorrectCount: number;
      unansweredCount: number;
      negativeMarks: number;
      percentage: number;
      status: string;
    }> = [];

    for (const sheet of pendingSheets) {
      const studentAnswers: string[] = JSON.parse(sheet.answers);
      let obtainedMarks = 0;
      let correctCount = 0;
      let incorrectCount = 0;
      let unansweredCount = 0;
      let negativeMarks = 0;

      for (const [qNo, keyData] of answerKeyMap) {
        const studentAns = studentAnswers[qNo - 1]?.toUpperCase() || '';
        if (!studentAns) {
          unansweredCount++;
        } else if (studentAns === keyData.answer) {
          correctCount++;
          obtainedMarks += keyData.marks;
        } else {
          incorrectCount++;
          negativeMarks += exam.negativeMarking;
        }
      }

      obtainedMarks = Math.max(0, obtainedMarks - negativeMarks);
      const percentage = exam.totalMarks > 0 ? Math.round((obtainedMarks / exam.totalMarks) * 10000) / 100 : 0;
      const status = percentage >= exam.passingPercent ? 'pass' : 'fail';

      allResults.push({
        examId,
        omrSheetId: sheet.id,
        studentName: sheet.studentName,
        rollNumber: sheet.rollNumber,
        totalMarks: exam.totalMarks,
        obtainedMarks,
        correctCount,
        incorrectCount,
        unansweredCount,
        negativeMarks,
        percentage,
        status,
      });
    }

    // Delete existing results for this exam to allow re-processing
    await db.result.deleteMany({ where: { examId } });

    // Create results
    for (const r of allResults) {
      await db.result.create({ data: r });
    }

    // Update sheet statuses
    for (const sheet of pendingSheets) {
      await db.oMRSheet.update({
        where: { id: sheet.id },
        data: { status: 'processed' },
      });
    }

    // Assign ranks based on obtainedMarks descending
    const sortedResults = await db.result.findMany({
      where: { examId },
      orderBy: { obtainedMarks: 'desc' },
    });

    for (let i = 0; i < sortedResults.length; i++) {
      await db.result.update({
        where: { id: sortedResults[i].id },
        data: { rank: i + 1 },
      });
    }

    processed = pendingSheets.length;

    return NextResponse.json({
      message: `Successfully processed ${processed} OMR sheets`,
      processed,
      totalResults: allResults.length,
    });
  } catch (error) {
    console.error('POST /api/results error:', error);
    return NextResponse.json({ error: 'Failed to process OMR sheets' }, { status: 500 });
  }
}
