import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/exam/[id] - Get single exam with details
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const exam = await db.exam.findUnique({
      where: { id },
      select: {
        id: true,
        name: true,
        subject: true,
        date: true,
        duration: true,
        totalQuestions: true,
        totalMarks: true,
        passingPercent: true,
        negativeMarking: true,
        optionsPerQ: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        _count: {
          select: {
            answerKeys: true,
            omrSheets: true,
            results: true,
          },
        },
      },
    });

    if (!exam) {
      return NextResponse.json(
        { error: 'Exam not found' },
        { status: 404 }
      );
    }

    // Get OMR sheet status breakdown
    const sheetStatusCounts = await db.oMRSheet.groupBy({
      by: ['status'],
      where: { examId: id },
      _count: { status: true },
    });

    const statusBreakdown: Record<string, number> = {};
    for (const s of sheetStatusCounts) {
      statusBreakdown[s.status] = s._count.status;
    }

    return NextResponse.json({
      data: {
        ...exam,
        sheetStatusBreakdown: statusBreakdown,
      },
    });
  } catch (error) {
    console.error('Error fetching exam:', error);
    return NextResponse.json(
      { error: 'Failed to fetch exam' },
      { status: 500 }
    );
  }
}
