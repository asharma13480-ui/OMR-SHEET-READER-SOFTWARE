import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/exam — list all exams (supports ?status=completed&limit=200)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = request.nextUrl;
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '200', 10);

    const where = status ? { status } : {};

    const exams = await db.exam.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        _count: {
          select: {
            answerKeys: true,
            omrSheets: true,
            results: true,
          },
        },
      },
    });
    return NextResponse.json({ exams });
  } catch (error) {
    console.error('GET /api/exam error:', error);
    return NextResponse.json({ error: 'Failed to fetch exams' }, { status: 500 });
  }
}

// POST /api/exam — create a new exam
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, subject, date, duration, totalQuestions, totalMarks, passingPercent, negativeMarking, optionsPerQ } = body;

    if (!name || !name.trim()) {
      return NextResponse.json({ error: 'Exam name is required' }, { status: 400 });
    }

    const exam = await db.exam.create({
      data: {
        name: name.trim(),
        subject: subject?.trim() || null,
        date: date || null,
        duration: duration || null,
        totalQuestions: parseInt(totalQuestions) || 100,
        totalMarks: parseFloat(totalMarks) || 100,
        passingPercent: parseFloat(passingPercent) || 33,
        negativeMarking: parseFloat(negativeMarking) || 0,
        optionsPerQ: parseInt(optionsPerQ) || 4,
      },
    });

    return NextResponse.json({ exam }, { status: 201 });
  } catch (error) {
    console.error('POST /api/exam error:', error);
    return NextResponse.json({ error: 'Failed to create exam' }, { status: 500 });
  }
}

// PUT /api/exam — update an exam
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, name, subject, date, duration, totalQuestions, totalMarks, passingPercent, negativeMarking, optionsPerQ } = body;

    if (!id) {
      return NextResponse.json({ error: 'Exam ID is required' }, { status: 400 });
    }

    const exam = await db.exam.update({
      where: { id },
      data: {
        name: name?.trim(),
        subject: subject?.trim() || null,
        date: date || null,
        duration: duration || null,
        totalQuestions: parseInt(totalQuestions) || undefined,
        totalMarks: parseFloat(totalMarks) || undefined,
        passingPercent: parseFloat(passingPercent) || undefined,
        negativeMarking: parseFloat(negativeMarking) || undefined,
        optionsPerQ: parseInt(optionsPerQ) || undefined,
      },
    });

    return NextResponse.json({ exam });
  } catch (error) {
    console.error('PUT /api/exam error:', error);
    return NextResponse.json({ error: 'Failed to update exam' }, { status: 500 });
  }
}

// DELETE /api/exam — delete an exam
export async function DELETE(request: Request) {
  try {
    const body = await request.json();
    const { id } = body;

    if (!id) {
      return NextResponse.json({ error: 'Exam ID is required' }, { status: 400 });
    }

    await db.exam.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/exam error:', error);
    return NextResponse.json({ error: 'Failed to delete exam' }, { status: 500 });
  }
}
